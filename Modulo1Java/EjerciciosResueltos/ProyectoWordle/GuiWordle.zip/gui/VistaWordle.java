package gui;
import wordle.*;

import java.awt.event.ActionListener;

public interface VistaWordle {
    String NUEVO ="N";
    String INTENTO = "I";

    void controlador(ActionListener ctr);

    // Añade un intento a la lista de intentos
    void intento(int numIntento, String intento, String resultado);

    void solucion(String opalabra);

    // Añade un mensaje de error
    void mensaje(String msg);

    // Lee la palabra introducida por el usuario
    String palabra();

    // Borra la palabra introducida por el usuario
    void borraPalabra();

    // Se pone en modo juego y borra los intentos anteriores y mensajes
    void inicioDelJuego();

    // Se pone en modo no juego
    void finDelJuego();
}
