package gui;
import wordle.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class PanelWordle extends JPanel implements VistaWordle {
    private JLabel [][] jli;
    private Color colorFondo;

    private JButton jbIntento;
    private JTextField jtfIntento;
    private JButton jbNuevo;


    private JLabel jlMensaje;

    public PanelWordle() {
        jli = new JLabel[7][];
        for (int i = 0; i <= 6; i++) {
            jli[i] = new JLabel[6];
            for (int j = 0; j < 6; j++) {
                jli[i][j] = new JLabel(" ");
                Font font = jli[i][j].getFont();
                jli[i][j].setFont(font.deriveFont(64.0F));
                jli[i][j].setPreferredSize(new Dimension(60,60));
                jli[i][j].setOpaque(true);
                jli[i][j].setForeground(Color.WHITE);
                jli[i][j].setHorizontalAlignment(JLabel.CENTER);
            }
        }
        colorFondo = jli[0][0].getBackground();
        jbIntento = new JButton("Intento");
        Font font = jbIntento.getFont();
        jbIntento.setFont(font.deriveFont(32.0F));
        jtfIntento = new JTextField(5);
        jtfIntento.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                c = Character.toUpperCase(c);
                e.setKeyChar(c);
                super.keyTyped(e);
            }
        });
        font = jtfIntento.getFont();
        jtfIntento.setFont(font.deriveFont(64.0F));
        jbNuevo = new JButton("Empezar");
        font = jbNuevo.getFont();
        jbNuevo.setFont(font.deriveFont(32.0F));
        jlMensaje = new JLabel(" ");
        font = jlMensaje.getFont();
        jlMensaje.setFont(font.deriveFont(32.0F));
        jlMensaje.setForeground(Color.RED);
        JPanel supDerecho = new JPanel();
        supDerecho.setLayout(new GridLayout(2,1));
        supDerecho.add(jbNuevo);
        supDerecho.add(jbIntento);
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new GridLayout(1,2));
        panelSuperior.add(jtfIntento);
        panelSuperior.add(supDerecho);
        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new GridLayout(7,6));
        for (int f =0;f < 7; f++)
            for (int c = 0; c < 6; c++)
                panelCentral.add(jli[f][c]);
        setLayout(new BorderLayout());
        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);
        add(jlMensaje, BorderLayout.SOUTH);
    }

    public void intento(int numIntento, String palabra, String patron) {
        jlMensaje.setText(" ");


        if (numIntento != 7) jli[numIntento-1][0].setText(Integer.toString(numIntento));
        jli[numIntento-1][0].setBackground(Color.GRAY);
        jli[numIntento-1][0].setBorder(BorderFactory.createLineBorder(Color.BLACK));

        for (int pos = 0; pos < palabra.length();pos++) {
            char c = palabra.charAt(pos);
            char m = patron.charAt(pos);
            JLabel jl = jli[numIntento-1][pos+1];
            if (m =='V')
                jl.setBackground(Color.GREEN);
            else if (m == 'A')
                jl.setBackground(new Color(192,192,0));
            else
                jl.setBackground(Color.BLACK);
            jl.setText(Character.toString(c));
        }
    }

    public void solucion(String palabra) {
        intento(7,palabra,"VVVVV");
    }

    public void controlador(ActionListener ctr) {
        jbIntento.addActionListener(ctr);
        jbIntento.setActionCommand(INTENTO);
        jbNuevo.addActionListener(ctr);
        jbNuevo.setActionCommand(NUEVO);
        jtfIntento.addActionListener(ctr);
        jtfIntento.setActionCommand(INTENTO);
    }

    public void mensaje(String msg) {
        jlMensaje.setText(msg);
    }

    public String palabra() {
        return jtfIntento.getText();
    }

    public void inicioDelJuego() {
        jbIntento.setEnabled(true);
        jtfIntento.setEnabled(true);
        borraIntentos();
        mensaje(" ");
    }

    public void finDelJuego() {
        jbIntento.setEnabled(false);
        jtfIntento.setEnabled(false);
    }

    public void borraPalabra() {
        jtfIntento.setText("");
    }

    private void borraIntentos() {
        for (int f = 0 ; f < 7;f++)
            for (int c = 0; c < 6; c++) {
                jli[f][c].setText(" ");
                jli[f][c].setBackground(colorFondo);
                jli[f][c].setBorder(null);
        }
    }
}

