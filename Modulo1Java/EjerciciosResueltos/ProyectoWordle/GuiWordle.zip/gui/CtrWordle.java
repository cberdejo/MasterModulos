package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import wordle.*;
public class CtrWordle implements ActionListener {
    private VistaWordle vista;
    private Wordle wordle;
    private int numIntento;

    public CtrWordle(VistaWordle vista, String fichero) throws IOException {
        this.vista = vista;
        Wordle.leePalabras(fichero);
        vista.finDelJuego();
        numIntento = 1;
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        switch (cmd) {
            case VistaWordle.NUEVO:
                wordle = new Wordle(); // WordleM
                vista.inicioDelJuego();
                numIntento = 1;
                break;
            case VistaWordle.INTENTO:
                String palabra = vista.palabra();
                vista.borraPalabra();
                Respuesta res = wordle.intento(palabra);
                switch (res) {
                    case Fallo(String msg):
                        vista.mensaje(msg);
                        break;
                    case Movimiento(String intento, String resultado):
                        vista.intento(numIntento,intento, resultado);
                        if (resultado.equals("VVVVV")) {
                            vista.mensaje("Acertaste");
                            vista.finDelJuego();
                        } else if (numIntento == 6) {
                            vista.solucion(wordle.getSecreta());
                            vista.mensaje("Fallaste");
                            vista.finDelJuego();
                        }
                        numIntento++;

                }
        }

    }
}
