import gui.CtrWordle;
import gui.PanelWordle;
import gui.VistaWordle;

import javax.swing.*;
import java.io.IOException;

public class MainGUIWordle {
    public static void main(String[] args) {

        try {
            // MVC
            VistaWordle vista = new PanelWordle();
            CtrWordle ctr = new CtrWordle(vista, "data/palabras.txt");
            vista.controlador(ctr);

            JFrame ventana = new JFrame("Wordle");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setContentPane((JPanel)vista);
            ventana.pack();
            ventana.setVisible(true);
        } catch (IOException e) {
            System.err.println("Fichero de palabras no encontrado");
        }
    }
}
